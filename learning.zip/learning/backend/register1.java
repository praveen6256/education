import connection.dbconnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet(urlPatterns = {"/register1"})
public class register1 extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, FileUploadException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(true);
        try {
            String Name="", Mail="", Password="", DOB="", Phone_no="", Gender="", Address="";
            
            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setSizeThreshold(4012);
            ServletFileUpload upload = new ServletFileUpload(factory);

            List items = null;
            try {
                items = upload.parseRequest(request);
            } catch (FileUploadException e) {
                e.printStackTrace();
            }

            Iterator iter = items.iterator();
            while (iter.hasNext()) {
                FileItem item = (FileItem) iter.next();
                if (item.isFormField()) {
                    String name = item.getFieldName();
                    String value = item.getString();
                    
                    if (name.equalsIgnoreCase("Name")) {
                        Name = value;
                    } else if (name.equalsIgnoreCase("Mail")) {
                        Mail = value;
                    } else if (name.equalsIgnoreCase("Password")) {
                        Password = value;
                    } else if (name.equalsIgnoreCase("DOB")) {
                        DOB = value;
                    } else if (name.equalsIgnoreCase("Phone_no")) {
                        Phone_no = value;
                    } else if (name.equalsIgnoreCase("Gender")) {
                        Gender = value;
                    } else if (name.equalsIgnoreCase("Address")) {
                        Address = value;
                    } else {
                        System.out.println("ERROR");
                    }
                }
            }
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con7 = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","admin");
            
            String query="Select * from details where Mail='"+Mail+"'";
            Statement st = con7.createStatement();
            ResultSet rs = st.executeQuery(query);

            if(rs.next()) {
                session.setAttribute("msg","Already exist Please Check Values");
                response.sendRedirect("sellerhome.jsp");  
            } else {
                PreparedStatement st7 = con7.prepareStatement("insert into details values (?,?,?,?,?,?,?,?)");
                st7.setInt(1, 0);
                st7.setString(2, Name);
                st7.setString(3, Mail);
                st7.setString(4, Password);
                st7.setString(5, DOB);
                st7.setString(6, Phone_no);
                st7.setString(7, Gender);
                st7.setString(8, Address);

                int i = st7.executeUpdate();
                session.setAttribute("msg","Successfully Registered");
                response.sendRedirect("login.jsp");
            }   
        } catch(Exception e) {
            out.println(e);
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (FileUploadException | ClassNotFoundException | SQLException ex) {
            Logger.getLogger(register1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (FileUploadException | ClassNotFoundException | SQLException ex) {
            Logger.getLogger(register1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}